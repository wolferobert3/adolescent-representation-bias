#!/bin/bash
set -e

make

CORPUS_ZIP=/content/drive/MyDrive/kidsbias/nepali_data/nepali_embedding_data.zip
CORPUS=nepali_embedding_data
VOCAB_FILE=vocab.txt
COOCCURRENCE_FILE=cooccurrence.bin
COOCCURRENCE_SHUF_FILE=cooccurrence.shuf.bin
BUILDDIR=build
VERBOSE=2
MEMORY=4.0
VOCAB_MIN_COUNT=5
VECTOR_SIZE=300
MAX_ITER=20
WINDOW_SIZE=10
BINARY=2
NUM_THREADS=4
X_MAX=100

SAVE_FILE=/content/drive/MyDrive/kidsbias/glovetraining/glovecheckpoints/nepali_glove_vectors
SAVE_GRAD=/content/drive/MyDrive/kidsbias/glovetraining/glovecheckpoints/nepali_glove_grad

CHECKPOINT_EVERY=5
SAVE_SQGRAD=1

DATA_DIR=/content/drive/MyDrive/kidsbias/glovetraining/glovedata
MODEL_DIR=/content/drive/MyDrive/kidsbias/glovetraining/glovecheckpoints

LOAD_INIT_PARAMS=0
LOAD_INIT_SQGRAD=0

INIT_PARAM_FILE=0
INIT_GRAD_FILE=0

if [ -n "$(ls -A $DATA_DIR 2>/dev/null)" ]
then
  echo "Copying files from $DATA_DIR"
    cp $DATA_DIR/* .
else
  echo "$DATA_DIR is empty, copying files from $CORPUS_ZIP"
  # Copy corpus file to current directory
  cp $CORPUS_ZIP . && unzip nepali_embedding_data.zip
fi

if [ -f "$VOCAB_FILE" ]; then
    echo "$VOCAB_FILE already exists, skipping vocab creation"
else
    echo "$ $BUILDDIR/vocab_count -min-count $VOCAB_MIN_COUNT -verbose $VERBOSE < $CORPUS > $VOCAB_FILE"
    $BUILDDIR/vocab_count -min-count $VOCAB_MIN_COUNT -verbose $VERBOSE < $CORPUS > $VOCAB_FILE
    cp $VOCAB_FILE $DATA_DIR
fi

if [ -f "$COOCCURRENCE_FILE" ]; then
    echo "$COOCCURRENCE_FILE already exists, skipping cooccurrence matrix creation"
else
    echo "$ $BUILDDIR/cooccur -memory $MEMORY -vocab-file $VOCAB_FILE -verbose $VERBOSE -window-size $WINDOW_SIZE < $CORPUS > $COOCCURRENCE_FILE"
    $BUILDDIR/cooccur -memory $MEMORY -vocab-file $VOCAB_FILE -verbose $VERBOSE -window-size $WINDOW_SIZE < $CORPUS > $COOCCURRENCE_FILE
    cp $COOCCURRENCE_FILE $DATA_DIR
fi

if [ -f "$COOCCURRENCE_SHUF_FILE" ]; then
    echo "$COOCCURRENCE_SHUF_FILE already exists, skipping shuffle"
else
    echo "$ $BUILDDIR/shuffle -memory $MEMORY -verbose $VERBOSE < $COOCCURRENCE_FILE > $COOCCURRENCE_SHUF_FILE"
    $BUILDDIR/shuffle -memory $MEMORY -verbose $VERBOSE < $COOCCURRENCE_FILE > $COOCCURRENCE_SHUF_FILE
    cp $COOCCURRENCE_SHUF_FILE $DATA_DIR
fi

# Get name of subdirectory in model directory with largest last character
# Check if model directory is empty
if [ -z "$(ls -A $MODEL_DIR 2>/dev/null)" ]; then

    # Make a new subdirectory with the name 0
    mkdir -p $MODEL_DIR/0

    # Set the save file to the new subdirectory
    SAVE_FILE=$MODEL_DIR/0/nepali_glove_vectors
    SAVE_GRAD=$MODEL_DIR/0/nepali_glove_grad

else

    SUBDIR=$(ls -d $MODEL_DIR/*/ | xargs -n 1 basename | sort -V | tail -n 1)

    # Get .bin file with largest last three characters
    VEC_FILE=$(ls $MODEL_DIR/$SUBDIR/nepali_glove_vectors*.bin | sort -k2 -ts -n -r | head -1)
    echo $VEC_FILE
    LOAD_INIT_PARAMS=1
    INIT_PARAM_FILE=$VEC_FILE

    # Get .grad file with largest last three characters
    GRAD_FILE=$(ls $MODEL_DIR/$SUBDIR/nepali_glove_grad*.bin | sort -k2 -ts -n -r | head -1)
    echo $GRAD_FILE
    LOAD_INIT_SQGRAD=1
    INIT_GRAD_FILE=$GRAD_FILE

    # Make a new subdirectory with one larger last character
    NEW_SUBDIR=$(ls $MODEL_DIR | sort -r | head -1)
    NEW_SUBDIR="$((NEW_SUBDIR + 1))"
    
    # Make a new subdirectory with the new name
    mkdir -p $MODEL_DIR/$NEW_SUBDIR

    # Set the save file to the new subdirectory
    SAVE_FILE=$MODEL_DIR/$NEW_SUBDIR/nepali_glove_vectors
    SAVE_GRAD=$MODEL_DIR/$NEW_SUBDIR/nepali_glove_grad

fi

echo "$ $BUILDDIR/glove -save-file $SAVE_FILE -threads $NUM_THREADS -input-file $COOCCURRENCE_SHUF_FILE -x-max $X_MAX -iter $MAX_ITER -vector-size $VECTOR_SIZE -binary $BINARY -vocab-file $VOCAB_FILE -verbose $VERBOSE -checkpoint-every $CHECKPOINT_EVERY -save-gradsq $SAVE_SQGRAD -load-init-gradsq $LOAD_INIT_SQGRAD -load-init-param $LOAD_INIT_PARAMS -init-param-file $INIT_PARAM_FILE -init-gradsq-file $INIT_GRAD_FILE -gradsq-file $SAVE_GRAD"
$BUILDDIR/glove -save-file $SAVE_FILE -threads $NUM_THREADS -input-file $COOCCURRENCE_SHUF_FILE -x-max $X_MAX -iter $MAX_ITER -vector-size $VECTOR_SIZE -binary $BINARY -vocab-file $VOCAB_FILE -verbose $VERBOSE -checkpoint-every $CHECKPOINT_EVERY -save-gradsq $SAVE_SQGRAD -load-init-gradsq $LOAD_INIT_SQGRAD -load-init-param $LOAD_INIT_PARAMS -init-param-file $INIT_PARAM_FILE -init-gradsq-file $INIT_GRAD_FILE -gradsq-file $SAVE_GRAD